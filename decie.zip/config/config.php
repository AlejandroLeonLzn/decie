<?php
$_SESSION['host']="localhost";
$_SESSION['usr']="root";
$_SESSION['psw']="";
$_SESSION['bd']="decie";
?>	